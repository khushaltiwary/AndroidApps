package com.example.tic_tac_toe;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
ImageView imageViewCross,imageViewRound;
TextView textViewScore,resultTextView;
Button playAgain;

    /** 0: round, 1: cancel
     * 2 - empty state */
    int activePlayer=0;
    boolean gameActive = true;
    int[][] winningPositions = {{0, 1, 2}, {3, 4, 5}, {6, 7, 8}, {0, 3, 6}, {1, 4, 7}, {2, 5, 8}, {0, 4, 8}, {2, 4, 6}};

    int[] gameState = {2,2,2,2,2,2,2,2,2};
    String winner = "";

    public void dropIn(View view){

            //yellow=0  red=1 empty=2

            Button playAgainButton = findViewById(R.id.playAgainButton);
            TextView winnerTextView = findViewById(R.id.resultTextView);

            MediaPlayer mediaPlayer = MediaPlayer.create(getApplicationContext(),R.raw.button_pressed);
            mediaPlayer.start();

            ImageView counter = (ImageView) view;
            int tappedCounter = Integer.parseInt(counter.getTag().toString());

            if(gameState[tappedCounter] == 2 && gameActive) {

                gameState[tappedCounter] = activePlayer;

                counter.setTranslationY(-1000);

                if (activePlayer == 0) {
                    counter.setImageResource(R.drawable.oie_oie_trim_image);
                    activePlayer = 1;
                } else {
                    counter.setImageResource(R.drawable.cancel);
                    activePlayer = 0;
                }

                counter.animate().translationYBy(1000).rotation(360).setDuration(300);

                for (int[] win : winningPositions) {
                    if (gameState[win[0]] == gameState[win[1]]
                            && gameState[win[1]] == gameState[win[2]]
                            && gameState[win[0]] != 2) {

                        gameActive = false;
                        if (activePlayer == 1) {
                            winner = "Round";
                        } else {
                            winner = "Cross";
                        }
                        MediaPlayer mediaPlayer1 = MediaPlayer.create(getApplicationContext(),R.raw.win_sound_effect);
                        mediaPlayer1.start();
                        winnerTextView.setText(winner +  " has won!");

                        winnerTextView.setVisibility(View.VISIBLE);
                        playAgainButton.setVisibility(View.VISIBLE);
                    }

                }

            }
            //when all the positions gets filled but a player wins at the end
            for (int[] win : winningPositions) {
                if (gameState[0] != 2 && gameState[1] != 2 && gameState[2] != 2
                        && gameState[3] != 2 && gameState[4] != 2 && gameState[5] != 2
                        && gameState[6] != 2 && gameState[7] != 2 && gameState[8] != 2
                        && gameState[win[0]] == gameState[win[1]] && gameState[win[1]] == gameState[win[2]]
                        && gameState[win[0]] != 2) {

                    gameActive = false;
                    if (activePlayer == 1) {
                        winner = "Round";
                    } else {
                        winner = "Cross";
                    }

                    winnerTextView.setText(winner +  " has won!");
                    MediaPlayer mediaPlayer2 = MediaPlayer.create(getApplicationContext(),R.raw.win_sound_effect);
                    mediaPlayer2.start();

                    winnerTextView.setVisibility(View.VISIBLE);

                    playAgainButton.setVisibility(View.VISIBLE);
                }
                //when all positions are filled and no one wins
                else if(gameState[0] != 2 && gameState[1] != 2 && gameState[2] != 2 && gameState[3] != 2
                        && gameState[4] != 2 && gameState[5] != 2 && gameState[6] != 2
                        && gameState[7] != 2 && gameState[8] != 2
                        && gameState[win[0]] != gameState[win[1]] && gameState[win[1]] != gameState[win[2]]
                        && gameState[win[0]] != 2){

                    winnerTextView.setText("nobody has won");
                    MediaPlayer mediaPlayer3 = MediaPlayer.create(getApplicationContext(),R.raw.lose_sound_effect);
                    mediaPlayer3.start();

                    winnerTextView.setVisibility(View.VISIBLE);
                    playAgainButton.setVisibility(View.VISIBLE);
                }
            }
        }

    public void playAgain(View view){
        Button playAgainButton = findViewById(R.id.playAgainButton);

        TextView winnerTextView = findViewById(R.id.resultTextView);

        winnerTextView.setVisibility(View.INVISIBLE);

        playAgainButton.setVisibility(View.INVISIBLE);

        androidx.gridlayout.widget.GridLayout gridLayout = findViewById(R.id.gridLayout);

        for(int i=0; i< gridLayout.getChildCount(); i++) {
            ImageView counter = (ImageView) gridLayout.getChildAt(i);
            // do stuff with child view

            counter.setImageDrawable(null);

        }


        for(int i=0;i<gameState.length;i++){
            gameState[i] = 2;
        }


        activePlayer = 0;

        gameActive = true;

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);

        imageViewRound = findViewById(R.id.imageView1);;
        resultTextView = findViewById(R.id.resultTextView);
        playAgain = findViewById(R.id.playAgainButton);

    }//End onCreate
}//End Main